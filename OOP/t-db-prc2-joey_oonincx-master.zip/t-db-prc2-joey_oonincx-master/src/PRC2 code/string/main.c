#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int main (int argc, char * argv[])
{
	char myName[] = "Inspector Gadget";

	printf("Name = %s -> size = %d - %d\n", myName, (int)strlen(myName), (int)sizeof(myName));
	//Prints Inspector Gadget size = 16-17
	//sizeof(myName) = 17 because of value \0 at end of string

	char otherName[] = "Inspector";

	printf("Compare %d\n", strcmp(myName, otherName));
	printf("Compare %d\n", strncmp(myName, otherName,9));

	myName[9] = '\0';
	printf("Name = %s -> size = %d\n", myName,(int)strlen(myName));
	printf("Compare %d\n", strcmp(myName, otherName));


	int index = 0;
	while(true) 
	{
		char current_char = myName[index];

		if(current_char == '\0') break;

		printf("%c\n", current_char);

		index++;
	}


	char yourName[] = "Frits";
	char* myName2 = "Frits";
	char* sameName = "Frits";
	char* friendsName = "Frank";

	//statement: false
	// 
	if(yourName != myName2) {
		printf("But our names are the same?\n");
		printf("Location of yourName: %p\n", yourName);
		printf("Location of nyName: %p\n", myName2);
		printf("Consider using <string.h>!\n");
	}
	//statement: true
	//beide waardes wijzen naar dezelfde geheugenplaats
	if(myName2 == sameName) {
		printf("There same...\n");
	}
	//statement: true
	//beide beginwaardez zijn hetzelfde.
	if(*yourName == *myName2) {
		printf("This can't be happening!?\n");
	}
	//statement: true
	//beide pointers beginnen met dezelfde waarde hierdoor is het true.
	if(*yourName == *friendsName)
	{
		printf("This is weird? %s oes not equal %s\n", yourName, friendsName);
	}
}
