#include <stdio.h>
int array[] = {10,11,12,13,14};  

double doubleArray[] = {39.210,30.210};


// Declare a pointer to the last element of array.
int* p = &array[sizeof(array) / sizeof(*array)-1];
double* d = &doubleArray[sizeof(doubleArray) / sizeof(*doubleArray)-1];

// Declare length of array
int arrayLength = sizeof(doubleArray) / sizeof(*doubleArray);

double averageNumber(double* array, int arrayLength)
{
     double result = 0;
    for(int i = 0; i < arrayLength+1; i++)
    {
        result += array[i];
    }
    double average = result / arrayLength;
    return average;
}
double arrayAdd(double* array, int arrayLength)
{
    double result = 0;
    for(int i = 0; i < arrayLength+1; i++)
    {
        result += array[i];
    }
    return result;
}

int arrayAddParameter(double* array, double*result)
{
    if(array == NULL)
    {
        return -1;
    }
    *result = arrayAdd(array, arrayLength);
    return 0;
}

int main(void)
{
    printf("Printing int array \n");
    for(int i = 0; i < 5; i++)
    {
        // Print the value at the pointer value
        printf("%d \n", *p);
        // Set the pointer to the previous array value
        p -= 1;

    }
    printf("Printing double array \n");
    for(int i = 0; i < *d; i++)
    {
        printf("%g \n", *d);
        d -= 1;
    }
    double total;
    double *p = &total;
    arrayAddParameter(doubleArray, p);
    printf("Total array values: ");
    printf("%g \n", total);
    double avg = averageNumber(doubleArray, arrayLength);
    printf("THe average number is : %g \n", avg);
}

