#include "animal.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
// Note: make sure to set 'resource_detector.h' as the last include.
#include "resource_detector.h"

//zegt success maar niet zichtbaar na verwijderen wel
//niet aan te tonen dat het werkt tenzij je laatste animal verwijdert(dit is dan de animal ervoor waardoor hij opschuift)
int addAnimal(const ANIMAL* animalPtr, ANIMAL* animalArray, unsigned int animalArrayLength, \
              unsigned int numberOfAnimalsPresent, unsigned int* newNumberOfAnimalsPresent) 
{
	*newNumberOfAnimalsPresent = numberOfAnimalsPresent;
	if(animalPtr == NULL || animalArray == NULL)
	{
		return -1;
	}
	if(animalArrayLength > numberOfAnimalsPresent)
	{
		animalArray[numberOfAnimalsPresent] = *animalPtr;
		*newNumberOfAnimalsPresent += 1;
		return 0;
	}
	else
	{
		return -1;
	}
}
//laatste animal wordt null tenzij er een animal achter zit
int removeAnimal(int animalId, ANIMAL* animalArray, unsigned int numberOfAnimalsPresent,
                unsigned int* newNumberOfAnimalsPresent) 
{
	*newNumberOfAnimalsPresent = numberOfAnimalsPresent;
	int removedAnimalsCount = 0;
	if(animalArray == NULL)
	{
		return -1;
	}
	for(int i =0; i < numberOfAnimalsPresent; i++)
	{
		if(animalArray[i].Id == animalId)
		{
			for(int j = i; j < numberOfAnimalsPresent; j++)
			{
				if(&animalArray[j+1] != NULL)
				{
					animalArray[j] = animalArray[j + 1];
				}
			}
			removedAnimalsCount++;
		}
	}
	if(removedAnimalsCount > 0)
	{
		*newNumberOfAnimalsPresent -= removedAnimalsCount;
		return removedAnimalsCount;
	}
	else if(removedAnimalsCount == 0)
	{
		return 0;
	}
}
//werkt volledig
int findAnimalById(int animalId, const ANIMAL* animalArray, unsigned int numberOfAnimalsPresent,
                    ANIMAL* animalPtr)
{
	for(int i =0; i < numberOfAnimalsPresent; i++)
	{
		if(animalArray[i].Id == animalId)
		{
			*animalPtr = animalArray[i];
			return 1;
		}
	}
	if(animalPtr == NULL)
	{
		return 0;
	}
 	else
	{
		return -1;
	}
}

/*-------------------------------------------------------------------------------*/
int sortAnimalsByAge(ANIMAL* animalArray, unsigned int numberOfAnimalsPresent)
{
	return 0;
}

int sortAnimalsByYearFound(ANIMAL* animalArray, unsigned int numberOfAnimalsPresent)
{
	return 0;
}

int sortAnimalsBySex(ANIMAL *animalArray, unsigned int numberOfAnimalsPresent)
{
	return 0;
}
