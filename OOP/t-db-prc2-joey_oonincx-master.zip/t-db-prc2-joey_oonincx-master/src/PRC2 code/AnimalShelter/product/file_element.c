#include "file_element.h"
// Note: make sure to set 'resource_detector.h' as the last include.
#include "resource_detector.h"

int readAnimals(const char* filename, ANIMAL* animalPtr, int nrAnimals) {
	return -1;
}

int writeAnimals(const char* filename, const ANIMAL* animalPtr, int nrAnimals) {
	return -1;
}

int getNrAnimalsInFile(const char* filename) {
	return -1;
}

int readAnimalFromFile(const char* filename, int filePosition, ANIMAL* animalPtr) {
	return -1;
}

int writeAnimalToFile(const char* filename, int filePosition, const ANIMAL* animalPtr) {
	return -1;
}

int renameAnimalInFile(const char* filename, int filePosition, const char* animalSurname) {
	return -1;
}