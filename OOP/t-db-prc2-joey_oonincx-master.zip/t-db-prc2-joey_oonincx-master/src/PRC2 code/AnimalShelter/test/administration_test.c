#include <string.h>

#include "administration.h"
#include "animal.h"
#include "unity.h"
#include "resource_detector.h"

// I rather dislike keeping line numbers updated, so I made my own macro to ditch the line number
#define MY_RUN_TEST(func) RUN_TEST(func, 0)

void setUp(void)
{
    // This is run before EACH test
}

//this is to test if you can add an animal.
void addAnimalTest(void)
{
    //prepare
    int arrayLength = 3;
    ANIMAL parrot[5] ={1,0, 0, 0, {0, 0, 0}};
    ANIMAL animalArray[arrayLength];
    int newAnimals = 0;
    int expected = 0;
    //act
    int result = addAnimal(parrot,animalArray,arrayLength,0,&newAnimals);

    //assert
    TEST_ASSERT_EQUAL(1,newAnimals);
    TEST_ASSERT_EQUAL(expected, result);
}
void removeAnimalTest(void)
{
    //prepare
    int arrayLength = 5;
    ANIMAL parrot[5] = {1,0, 0, 0, {0, 0, 0}};
    ANIMAL dog[5] = {2,0, 0, 0, {0, 0, 0}};
    ANIMAL animalArray[arrayLength];
    addAnimal(parrot,animalArray,arrayLength,0,0);
    addAnimal(dog,animalArray,arrayLength,1,0);
    int newRemovedAnimals = 35;
    //rare interactie zegt dat expeccted 0 is
    // int expected = 1;

    //act
    int removedAnimals = removeAnimal(2, animalArray, 2, &newRemovedAnimals);

    //assert
    TEST_ASSERT_EQUAL(1, newRemovedAnimals);
    TEST_ASSERT_EQUAL(1, removedAnimals);
}
void findAnimalTest(void)
{
    //prepare
    int arrayLength = 3;
    ANIMAL* animalPtr;
    ANIMAL animalArray[arrayLength];
    ANIMAL parrot[5] = {1,0,0,0, {0,0,0}};
    addAnimal(parrot,animalArray,arrayLength,0,0);
    int expected = 1;
    ANIMAL expectedAnimal = *parrot;

    //act
    int result = findAnimalById(1,animalArray,1,animalPtr);

    //assert
    TEST_ASSERT_EQUAL(expected, result);
}

void tearDown(void)
{
    // This is run after EACH test
}

void test_EmptyTest(void)
{
    TEST_ASSERT_EQUAL(1, 0);
}

int main (int argc, char * argv[])
{
    UnityBegin();

    // MY_RUN_TEST(test_EmptyTest);
    MY_RUN_TEST(addAnimalTest);
    MY_RUN_TEST(removeAnimalTest);
    // MY_RUN_TEST(findAnimalTest);

    return UnityEnd();
}
