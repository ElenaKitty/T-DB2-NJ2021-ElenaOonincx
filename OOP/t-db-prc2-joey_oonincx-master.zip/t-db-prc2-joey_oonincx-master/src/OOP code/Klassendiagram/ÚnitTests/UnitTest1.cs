using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ÚnitTests
{
    using Klassendiagram;
    [TestClass]
    public class UnitTest1
    {
        //testen of je twee waardes kunt vermenigvuldigen
        //Dit doormiddel van het maken van 2 getallen en deze te vermenigvuldigen via de calculator functie multiply.
        //Dit wordt gedaan zodat we weten dat de multiply functie goet werkt.
        [TestMethod]
        public void testCalculator()
        {
            //arrange
            int number1 = 5;
            int number2 = 6;
            int expected = 30;

            Calculator calc = new Calculator();

            //act
            double result = calc.Multiply(number1, number2);

            //Assert
            Assert.AreEqual(expected, result);
        }
        //testen of je een student zijn naam kunt veranderen
        //Dit doormiddel van het maken van een student met een naame. Hierna veranderen we zijn naam naar iets nieuws.
        //Dit wordt gedaan zodat we weten dat de mogelijkheid tot namen veranderen werkt.
        [TestMethod]
        public void testStudent()
        {
            string oldName = "Hans";
            Student Hans = new Student(oldName, "FontysWeg 123");
            string newName = "Piet";

            Hans.Name = newName;

            Assert.AreEqual(newName, Hans.Name);
        }
        //testen of je de aantal zijdes van een dice kan meegeven.
        //Dit doormiddel van het maken van een dobbelsteen met een bepaald aantal zijdes. Hierna kijken we of dat goed is gegaan.
        //Dit wordt gedaan zodat we weten dat we een dice kunnen maken met een bepaald aantal zijden.
        [TestMethod]
        public void testDice()
        {
            int sides = 22;

            Dice dice = new Dice(sides);

            Assert.AreEqual(sides, dice.Sides);
        }
    }
}
