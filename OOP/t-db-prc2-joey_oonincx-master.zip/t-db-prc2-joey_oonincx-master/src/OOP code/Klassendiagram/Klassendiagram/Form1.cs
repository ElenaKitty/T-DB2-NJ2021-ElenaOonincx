﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klassendiagram
{
    public partial class Form1 : Form
    {
        private Dice dice;
        private Student student;
        private Calculator calculator;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(dice.Throw().ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dice.ResetStatistics();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int sides = GetIntValue(textBox1);
            dice = new Dice(sides);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int side = GetIntValue(textBox2);
            MessageBox.Show(dice.NrOfTimesThrown(side).ToString());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dice = new Dice();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            student = new Student(nameBox.Text, addressBox.Text);
            MessageBox.Show("Student Created");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Name: " + student.Name + ", Address: " + student.Address);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            //add
            double number1 = GetDoubleValue(numberBox);
            double number2 = GetDoubleValue(numberBox2);
            calculator = new Calculator();
            calculator.Add(number1, number2);
            resultBox.Text = calculator.Result.ToString();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //substract
            double number1 = GetDoubleValue(numberBox);
            double number2 = GetDoubleValue(numberBox2);
            calculator = new Calculator();
            calculator.Substract(number1, number2);
            resultBox.Text = calculator.Result.ToString();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            //multiply
            double number1 = GetDoubleValue(numberBox);
            double number2 = GetDoubleValue(numberBox2);
            calculator = new Calculator();
            calculator.Multiply(number1, number2);
            resultBox.Text = calculator.Result.ToString();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            //divide

            double number1 = GetDoubleValue(numberBox);
            double number2 = GetDoubleValue(numberBox2);
            calculator = new Calculator();
            calculator.Divide(number1, number2);
            resultBox.Text = calculator.Result.ToString();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //clear
            calculator = new Calculator();
            calculator.Clear();
            numberBox.Text = "";
            numberBox2.Text = "";
            resultBox.Text = "";
        }
        private double GetDoubleValue(TextBox box1)
        {
            double number1 = 0;
            double.TryParse(box1.Text, out number1);
            return number1;
        }
        private int GetIntValue(TextBox box1)
        {
            int side = 0;
            int.TryParse(box1.Text, out side);
            return side;
        }
    }
}
