﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klassendiagram
{
    public class Dice
    {
        public int Sides { get; set; }
        private int[] sideThrown;

        public Dice()
        {
            Sides = 6;
            sideThrown = new int[Sides];
        }
        public Dice(int sides)
        {
            if(sides < 3)
            {
                Sides = 3;
            }
            else
            {
                Sides = sides;
            }
            sideThrown = new int[Sides];
        }
        
        public int Throw()
        {
            Random rnd = new Random();
            int thrown = rnd.Next(1, Sides);
            sideThrown[thrown] += 1;
            return thrown;
        }
        public int NrOfTimesThrown(int side)
        {
            int result = sideThrown[side];
            return result;
        }
        public void ResetStatistics()
        {
            for(int i =0; i < Sides; i++)
            {
                sideThrown[i] = 0;
            }
        }
    }
}
