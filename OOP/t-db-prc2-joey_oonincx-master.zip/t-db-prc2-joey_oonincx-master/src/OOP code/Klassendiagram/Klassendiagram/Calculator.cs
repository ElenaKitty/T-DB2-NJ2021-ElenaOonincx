﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klassendiagram
{
    public class Calculator
    {
        public double Result { get; set; }

        public Calculator()
        {
            
        }
        public double Add(double number1, double number2)
        {
            Result = number1 + number2;
            return Result;
        }
        public double Substract(double number1, double number2)
        {
            Result = number1 - number2;
            return Result;
        }
        public double Multiply(double number1, double number2)
        {
            Result = number1 * number2;
            return Result;
        }
        public double Divide(double number1, double number2)
        {
            Result = number1 / number2;
            return Result;
        }
        public void Clear()
        {
            Result = 0;
        }
    }
}
