﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnimalShelter
{
    public partial class AdministrationForm : Form
    {
        /// <summary>
        /// The (only) animal in this administration (for now....)
        /// </summary>
        private Animal animal;

        /// <summary>
        /// Creates the form for doing adminstrative tasks
        /// </summary>
        public AdministrationForm()
        {
            InitializeComponent();
            animalTypeComboBox.SelectedIndex = 0;
            animal = null;
        }

        /// <summary>
        /// Create an Animal object and store it in the administration.
        /// If "Dog" is selected in the animalTypeCombobox then a Dog object should be created.
        /// If "Cat" is selected in the animalTypeCombobox then a Cat object should be created.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void createAnimalButton_Click(object sender, EventArgs e)
        {
            try
            {
                int chipNumber = int.Parse(chipBox.Text);
                SimpleDate birth = new SimpleDate(birthBox.Value.Day, birthBox.Value.Month, birthBox.Value.Year);
                SimpleDate walk = new SimpleDate(walkBox.Value.Day, walkBox.Value.Month, walkBox.Value.Year);
                if (animalTypeComboBox.Text == "Dog")
                {
                    animal = new Dog(chipNumber, birth, nameBox.Text, walk);
                    MessageBox.Show("Dog created");
                }
                if (animalTypeComboBox.Text == "Cat")
                {
                    animal = new Cat(chipNumber, birth, nameBox.Text, habitsBox.Text);
                    MessageBox.Show("Cat created");
                }
            }
            catch(Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        /// <summary>
        /// Show the info of the animal referenced by the 'animal' field. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void showInfoButton_Click(object sender, EventArgs e)
        {
            if(animal is null)
            {
                outputBox.Text = "No animal registered";
            }
            else if(animal is Dog)
            {
                outputBox.Text = animal.ToString();
            }
            else if(animal is Cat)
            {
                outputBox.Text = animal.ToString();
            }
        }
    }
}
